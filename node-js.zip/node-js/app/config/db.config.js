module.exports = {
    HOST: "54.169.135.105",
    USER: "tor",
    PASSWORD: "tor12345678",
    DB: "tor",
    dialect: "postgres",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };
  